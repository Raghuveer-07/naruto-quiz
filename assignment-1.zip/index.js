score=0;
highScore = 5;
var ReadLineSync = require('readline-sync');

console.log("welcome to the naruto quiz")

var name = ReadLineSync.question("what is you name shinobi ?");

console.log(name+" A stunning name for a shinobi like you. \n So, let's start !!! \n Remember there is negative marking for wrong answer.")

questionOne = {
  question: "what is nine tails real name ? \n a- sakura \n b- chomei \n c- kurama\n",
  answer: "kurama"
};

questionTwo = {
  question: "what is naruto's nature type ? \n a- fire \n b- lightining \n c- wind\n",
  answer: "wind"
};

questionThree = {
  question: "sasuke is from which clan ? \n a- uchiha \n b- uzumaki \n c- namikaze\n",
  answer: "uchiha"
};

questionFour = {
  question: "what is naruto's main jutsu ? \n a- shadow clone jutsu \n b- rasengan \n c- fireball\n",
  answer: "shadow clone jutsu"
};

questionFive = {
  question: "what is sasuke's main jutsu ? \n a- shadow clone jutsu \n b- susanoo \n c- chidori\n",
  answer: "chidori"
};

var questions=[questionOne,questionTwo,questionThree,questionFour,questionFive];


function quiz(question,answer){
  var userAnswer = ReadLineSync.question(question);

  if (userAnswer.toLowerCase()===answer.toLowerCase()){
    console.log("You are right !")
    score +=1;
    console.log("your score is: " + score);
  }
  else{
    console.log ("You are Wrong !")
    score -=1;
    console.log("your score is: " + score);
  }
  
}

for (i=0;i<=questions.length-1;i++){
  var quest_ans=questions[i]
  quest=quest_ans.question
  ans=quest_ans.answer

  quiz(quest,ans);
   
  
}

console.log("your total score is "+score);

if (score<highScore){
   var diff=highScore-score
  console.log("You missed the high score by " +diff)
}

if (score===highScore){
  console.log("You have score the maximum congratulations !!!\n\n")
}

console.log("Thanks for Joining !!! have a great day.")